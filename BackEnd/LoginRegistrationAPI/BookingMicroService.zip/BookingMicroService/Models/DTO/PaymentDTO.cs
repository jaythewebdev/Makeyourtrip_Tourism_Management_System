﻿namespace BookingMicroService.Models.DTO
{
    public class PaymentDTO
    {
        public int PaymentId { get; set; }
        public string? PaymentStatus { get; set; }
    }
}
