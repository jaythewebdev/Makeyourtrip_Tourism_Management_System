﻿namespace BookingMicroService.Models.DTO
{
    public class BookingDTO
    {
        public int BookingId { get; set; }
        public string? BookingStatus { get; set; }
    }
}
