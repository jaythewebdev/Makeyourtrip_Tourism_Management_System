﻿namespace TourPackageMicroService.Models.DTO
{
    public class BookedCapacityDTO
    {
        public int TourId { get; set; }

        public int BookedCapacity { get; set; }

    }
}
